create
    definer = root@`%` procedure deleteActor(IN actorId int)
BEGIN
	DELETE FROM actor WHERE actor_id = actorId;
END;

